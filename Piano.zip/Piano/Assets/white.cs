﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class white : MonoBehaviour {
    bool isHit = false;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        gameObject.transform.position += new Vector3(0, -0.01f - BG.Instance.getSpeed(), 0);

        if(gameObject.transform.position.y < 2.5f && isHit == false)
        {
            BG.Instance.addWhite();
            isHit = true;
        }

        if(gameObject.transform.position.y < -2.5f)
        {
            BG.Instance.gameOver();
        }

        if(isHit == true)
        {
            if(Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x < gameObject.transform.position.x + 0.5f &&
                Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x > gameObject.transform.position.x - 0.5f &&
                Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y - 2f < gameObject.transform.position.y + 0.5f &&
                Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y - 2f < gameObject.transform.position.y - 0.5f)
            {
                Destroy(gameObject);
                BG.Instance.updateSpeed();
                BG.Instance.updateScore();
            }
        }


        if(Input.GetButtonDown("Fire1"))
        {
            Debug.Log(BG.Instance.getSpeed());
        }
    }
}
