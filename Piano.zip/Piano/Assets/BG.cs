﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BG : MonoBehaviour {
    public GameObject white;
    public static BG Instance;
    private float speed = 0f;

    public Text Score;
    public int score = 0;

    public GameObject title;
    public GameObject over;
    public GameObject start;
    public GameObject quit;
    public GameObject restart;


    public bool isPlaying = false;

	// Use this for initialization
	void Start () {
        Instance = this;
        over.SetActive(false);
        restart.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
       
	}

    public void addWhite()
    {
        if (isPlaying)
        {
            float f = Random.Range(-2.5f, 2.5f);
            Vector3 pos;
            if (f < -2f)
            {
                pos = new Vector3(-2.5f, 4.5f, 0);
            }
            else if (f < -0.5f)
            {
                pos = new Vector3(-1.5f, 4.5f, 0);

            }
            else if (f < 0.5f)
            {
                pos = new Vector3(-0.5f, 4.5f, 0);
            }
            else if (f < 1.5f)
            {
                pos = new Vector3(0.5f, 4.5f, 0);
            }
            else if (f < 2f)
            {
                pos = new Vector3(1.5f, 4.5f, 0);
            }
            else
            {
                pos = new Vector3(2.5f, 4.5f, 0);
            }

            Instantiate(white, pos, transform.rotation);
            

        }
    }

    public float getSpeed()
    {
        return speed;
    }

    public void updateSpeed()
    {
        speed += 0.01f;
    }

    public void updateScore()
    {
        score += 1;
        Score.text = "Score: " + score;
    }

    public void gameStart()
    {
        isPlaying = true;
        title.SetActive(false);
        start.SetActive(false);
        over.SetActive(false);
        quit.SetActive(false);
        addWhite();
    }

    public void gameOver()
    {
        isPlaying = false;
        over.SetActive(true);
        restart.SetActive(true);
        quit.SetActive(true);
    }

    public void reStart()
    {
        /*speed = 0f;
        score = 0;
        isPlaying = true;
        title.SetActive(false);
        start.SetActive(false);
        over.SetActive(false);
        quit.SetActive(false);
        addWhite();*/

        Application.LoadLevel(Application.loadedLevel);
    }

    public void Quit()
    {
        Application.Quit();
    }
}

